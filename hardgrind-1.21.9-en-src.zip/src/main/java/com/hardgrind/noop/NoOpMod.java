package com.hardgrind.noop;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.world.GameMode;

import static net.minecraft.server.command.CommandManager.literal;

/**
 * HardGrind No-OP (Singleplayer discipline)
 * - Blocks common cheat commands
 * - Forces SURVIVAL at join and during play
 * - Permission mixin ensures OP checks always fail
 */
public class NoOpMod implements ModInitializer {
    @Override
    public void onInitialize() {
        // Block typical cheat commands by overriding with no-ops
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            String[] blocked = {"op","deop","gamemode","give","tp","summon","effect","xp","enchant","locate","gamerule"};
            for (String cmd : blocked) {
                dispatcher.register(literal(cmd).executes(ctx -> deny(ctx.getSource().getPlayer())));
            }
        });

        // Enforce Survival on join and each tick (cheap guard)
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> enforceSurvival(handler.getPlayer()));
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                if (p.interactionManager.getGameMode() != GameMode.SURVIVAL) {
                    enforceSurvival(p);
                }
            }
        });
    }

    private int deny(ServerPlayerEntity player) {
        if (player != null) player.sendMessage(Text.literal("Cheat command is disabled."), false);
        return 0;
    }

    private void enforceSurvival(ServerPlayerEntity p) {
        p.changeGameMode(GameMode.SURVIVAL);
        p.sendMessage(Text.literal("Gamemode enforced: SURVIVAL"), false);
    }
}
