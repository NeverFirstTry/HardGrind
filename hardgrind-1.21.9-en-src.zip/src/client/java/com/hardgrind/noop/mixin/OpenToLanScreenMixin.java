package com.hardgrind.noop.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Disable the 'Open to LAN' screen by deactivating its buttons */
@Mixin(targets = "net.minecraft.client.gui.screen.OpenToLanScreen")
public class OpenToLanScreenMixin {
    @Inject(method = "init", at = @At("TAIL"))
    private void hardgrind$disableOpen(CallbackInfo ci) {
        try {
            Object self = this;
            var m = self.getClass().getMethod("children");
            var list = (java.util.List<?>) m.invoke(self);
            for (Object w : list) {
                try {
                    var f = w.getClass().getDeclaredField("active");
                    f.setAccessible(true);
                    if (f.getType() == boolean.class) f.setBoolean(w, false);
                } catch (Throwable ignored) {}
            }
        } catch (Throwable ignored) {}
    }
}
